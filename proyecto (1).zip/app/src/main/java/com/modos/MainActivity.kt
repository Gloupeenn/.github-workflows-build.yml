package com.modos

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(60, 60, 60, 60) }
        l.addView(TextView(this).apply { text = "Detector de modos\n\nActiva la burbuja y tocá el ♪ mientras suena algo en el celular."; textSize = 18f })
        l.addView(Button(this).apply { text = "Activar burbuja"; setOnClickListener { step() } })
        setContentView(l)
    }

    private fun step() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1); return
        }
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 2)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) step()
    }

    override fun onActivityResult(c: Int, res: Int, d: Intent?) {
        if (c == 2 && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, FloatService::class.java).putExtra("code", res).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
