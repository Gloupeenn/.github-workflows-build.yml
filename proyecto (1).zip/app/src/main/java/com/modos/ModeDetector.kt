package com.modos

import kotlin.math.*

object ModeDetector {
    private val notes = arrayOf("Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si")
    private val modes = listOf(
        "jónico" to intArrayOf(0, 2, 4, 5, 7, 9, 11), "dórico" to intArrayOf(0, 2, 3, 5, 7, 9, 10),
        "frigio" to intArrayOf(0, 1, 3, 5, 7, 8, 10), "lidio" to intArrayOf(0, 2, 4, 6, 7, 9, 11),
        "mixolidio" to intArrayOf(0, 2, 4, 5, 7, 9, 10), "eólico" to intArrayOf(0, 2, 3, 5, 7, 8, 10),
        "locrio" to intArrayOf(0, 1, 3, 5, 6, 8, 10)
    )

    fun detect(pcm: ShortArray, sr: Int): String {
        val n = 16384
        if (pcm.size < n * 2) return "Audio muy corto"
        var e = 0.0
        for (s in pcm) e += s.toDouble() * s
        if (sqrt(e / pcm.size) < 20) return "Sin audio\n(¿la app bloquea la captura?)"
        val ch = DoubleArray(12); val bs = DoubleArray(12)
        val re = DoubleArray(n); val im = DoubleArray(n)
        var p = 0
        while (p + n <= pcm.size) {
            for (i in 0 until n) { re[i] = pcm[p + i] * (0.5 - 0.5 * cos(2 * PI * i / n)); im[i] = 0.0 }
            fft(re, im)
            for (k in 1 until n / 2) {
                val f = k * sr.toDouble() / n
                if (f < 65 || f > 2000) continue
                val pc = (((12 * log2(f / 440) + 69).roundToInt()) % 12 + 12) % 12
                val m = sqrt(hypot(re[k], im[k]))
                ch[pc] += m
                if (f < 260) bs[pc] += m
            }
            p += n
        }
        val cs = ch.sum().coerceAtLeast(1e-9); val bt = bs.sum().coerceAtLeast(1e-9)
        val r = ArrayList<Pair<String, Double>>()
        for (t in 0 until 12) for ((name, iv) in modes) {
            val inE = iv.sumOf { ch[(t + it) % 12] / cs }
            r.add("${notes[t]} $name" to (2 * inE - 1) + 0.6 * ch[t] / cs + 0.8 * bs[t] / bt)
        }
        return r.sortedByDescending { it.second }.take(3).joinToString("\n") { it.first }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val a = re[i]; re[i] = re[j]; re[j] = a; val b = im[i]; im[i] = im[j]; im[j] = b }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                val h = len / 2
                for (k in 0 until h) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + h] * cr - im[i + k + h] * ci
                    val vi = re[i + k + h] * ci + im[i + k + h] * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + h] = ur - vr; im[i + k + h] = ui - vi
                    val t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }
}
