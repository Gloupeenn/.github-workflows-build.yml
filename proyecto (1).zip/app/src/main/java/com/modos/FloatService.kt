package com.modos

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.media.projection.*
import android.os.*
import android.view.*
import android.widget.TextView
import kotlin.math.abs

class FloatService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var tv: TextView
    private var proj: MediaProjection? = null
    private val ui = Handler(Looper.getMainLooper())
    private var busy = false

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("m", "Modos", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "m").setContentTitle("Detector de modos activo")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        if (!::tv.isInitialized) {
            proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
            proj?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, ui)
            addBubble()
        }
        return START_NOT_STICKY
    }

    private fun addBubble() {
        wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        tv = TextView(this).apply {
            text = "♪"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            minWidth = (56 * d).toInt(); minHeight = (56 * d).toInt()
            background = GradientDrawable().apply { setColor(0xEE3F51B5.toInt()); cornerRadius = 40 * d }
        }
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var t0 = 0L; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; t0 = System.currentTimeMillis(); moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 15 || abs(e.rawY - sy) > 15) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (System.currentTimeMillis() - t0 > 800) stopSelf() else listen() }
            }
            true
        }
        wm.addView(tv, lp)
    }

    private fun listen() {
        if (busy) return
        busy = true
        tv.textSize = 24f; tv.text = "…"
        Thread {
            var res: String
            try {
                val sr = 44100
                val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
                val rec = AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(sr * 2)
                    .setAudioPlaybackCaptureConfig(cfg).build()
                val buf = ShortArray(sr * 12)
                rec.startRecording()
                var n = 0
                while (n < buf.size) {
                    val r = rec.read(buf, n, minOf(4096, buf.size - n))
                    if (r <= 0) break
                    n += r
                }
                rec.stop(); rec.release()
                res = ModeDetector.detect(buf.copyOf(n), sr)
            } catch (e: Exception) { res = "Error: ${e.message}" }
            ui.post { tv.textSize = 15f; tv.text = res; busy = false }
        }.start()
    }

    override fun onDestroy() {
        if (::tv.isInitialized) wm.removeView(tv)
        proj?.stop()
        super.onDestroy()
    }
}
